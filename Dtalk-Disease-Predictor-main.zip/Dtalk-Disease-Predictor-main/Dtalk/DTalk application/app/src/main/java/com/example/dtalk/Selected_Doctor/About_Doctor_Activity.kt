package com.example.dtalk.Selected_Doctor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dtalk.R

class About_Doctor_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_doctor)
    }
}