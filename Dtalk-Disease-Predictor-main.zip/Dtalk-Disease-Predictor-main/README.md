# Disease_prediction
It was a group project done by me and 2 other members of my class where we have created a demo application named Dtalk for predicting the possible disease using the symptoms of patient.

![1 (4)](https://user-images.githubusercontent.com/74171135/148676965-b20d9888-b53f-4af9-8eda-e026d65d62e2.jpeg)

DtaLK  is an android application that helps our users to connect with their doctors online.
User can choose any of the Specialized Doctors from the list and can have a real-time chat with their doctors.
DtaLK is also equipped with another exciting feature of Disease Prediction model which is based on ML algorithms.


<b>**Objective of the work** </b>
To provide Disease Prediction models to predict from which disease our user is suffering from. To ensure that users just have to provide their symptoms into the app and ML model will predict user’s disease and provide the appropriate Doctors.

**Requirements** : Go to android studio and run our graddle file which will run the application in your system.



Dtalk is made up on the Kotlin, Python 3.8, Firebase(database). UI/UX of the Dtalk application is made with help of Adobe XD, Python is used for prediction of the disease using a pretrained model, and the constraints of that model were stored in a binary file, that binary file was imported in Android Studio and embedded into Kotlin





https://user-images.githubusercontent.com/74171135/231319801-b6f6325e-caa9-4fd8-aed1-097fc32edd78.mp4

Author - Manu Prakash Choudhary
